#ifndef _MD5_H_ 
#define _MD5_H_ 


char* MD5String( char* string, int DataLen); 


bool MD5Check( char *md5string, char* lpDataBuf, int DataLen); 

#endif //_MD5_H_ 
